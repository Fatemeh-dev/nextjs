"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/post_id";
exports.ids = ["pages/post_id"];
exports.modules = {

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fpost_id&preferredRegion=&absolutePagePath=.%2Fpages%5Cpost_id.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fpost_id&preferredRegion=&absolutePagePath=.%2Fpages%5Cpost_id.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./node_modules/next/dist/pages/_document.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./node_modules/next/dist/pages/_app.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\post_id.js */ \"./pages/post_id.js\");\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'default'));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticProps');\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticPaths');\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'getServerSideProps');\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'config');\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'reportWebVitals');\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticProps');\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticPaths');\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticParams');\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerProps');\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerSideProps');\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/post_id\",\n        pathname: \"/post_id\",\n        // The following aren't used in production.\n        bundlePath: '',\n        filename: ''\n    },\n    components: {\n        // default export might not exist when optimized for data only\n        App: (private_next_pages_app__WEBPACK_IMPORTED_MODULE_4___default()),\n        Document: (private_next_pages_document__WEBPACK_IMPORTED_MODULE_3___default())\n    },\n    userland: _pages_post_id_js__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGcG9zdF9pZCZwcmVmZXJyZWRSZWdpb249JmFic29sdXRlUGFnZVBhdGg9LiUyRnBhZ2VzJTVDcG9zdF9pZC5qcyZhYnNvbHV0ZUFwcFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2FwcCZhYnNvbHV0ZURvY3VtZW50UGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfZG9jdW1lbnQmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUF3RjtBQUNoQztBQUNFO0FBQzFEO0FBQ3lEO0FBQ1Y7QUFDL0M7QUFDZ0Q7QUFDaEQ7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLDhDQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLHVCQUF1Qix3RUFBSyxDQUFDLDhDQUFRO0FBQ3JDLHVCQUF1Qix3RUFBSyxDQUFDLDhDQUFRO0FBQ3JDLDJCQUEyQix3RUFBSyxDQUFDLDhDQUFRO0FBQ3pDLGVBQWUsd0VBQUssQ0FBQyw4Q0FBUTtBQUM3Qix3QkFBd0Isd0VBQUssQ0FBQyw4Q0FBUTtBQUM3QztBQUNPLGdDQUFnQyx3RUFBSyxDQUFDLDhDQUFRO0FBQzlDLGdDQUFnQyx3RUFBSyxDQUFDLDhDQUFRO0FBQzlDLGlDQUFpQyx3RUFBSyxDQUFDLDhDQUFRO0FBQy9DLGdDQUFnQyx3RUFBSyxDQUFDLDhDQUFRO0FBQzlDLG9DQUFvQyx3RUFBSyxDQUFDLDhDQUFRO0FBQ3pEO0FBQ08sd0JBQXdCLGtHQUFnQjtBQUMvQztBQUNBLGNBQWMsa0VBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsYUFBYSwrREFBVztBQUN4QixrQkFBa0Isb0VBQWdCO0FBQ2xDLEtBQUs7QUFDTCxZQUFZO0FBQ1osQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VzUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL3BhZ2VzL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgaG9pc3QgfSBmcm9tIFwibmV4dC9kaXN0L2J1aWxkL3RlbXBsYXRlcy9oZWxwZXJzXCI7XG4vLyBJbXBvcnQgdGhlIGFwcCBhbmQgZG9jdW1lbnQgbW9kdWxlcy5cbmltcG9ydCAqIGFzIGRvY3VtZW50IGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2RvY3VtZW50XCI7XG5pbXBvcnQgKiBhcyBhcHAgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fYXBwXCI7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlc1xcXFxwb3N0X2lkLmpzXCI7XG4vLyBSZS1leHBvcnQgdGhlIGNvbXBvbmVudCAoc2hvdWxkIGJlIHRoZSBkZWZhdWx0IGV4cG9ydCkuXG5leHBvcnQgZGVmYXVsdCBob2lzdCh1c2VybGFuZCwgJ2RlZmF1bHQnKTtcbi8vIFJlLWV4cG9ydCBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsICdnZXRTdGF0aWNQcm9wcycpO1xuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsICdnZXRTdGF0aWNQYXRocycpO1xuZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U2VydmVyU2lkZVByb3BzJyk7XG5leHBvcnQgY29uc3QgY29uZmlnID0gaG9pc3QodXNlcmxhbmQsICdjb25maWcnKTtcbmV4cG9ydCBjb25zdCByZXBvcnRXZWJWaXRhbHMgPSBob2lzdCh1c2VybGFuZCwgJ3JlcG9ydFdlYlZpdGFscycpO1xuLy8gUmUtZXhwb3J0IGxlZ2FjeSBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTdGF0aWNQcm9wcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTdGF0aWNQYXRocycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhcmFtcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUGFyYW1zJyk7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgJ3Vuc3RhYmxlX2dldFNlcnZlclByb3BzJyk7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTZXJ2ZXJTaWRlUHJvcHMnKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTLFxuICAgICAgICBwYWdlOiBcIi9wb3N0X2lkXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9wb3N0X2lkXCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogJycsXG4gICAgICAgIGZpbGVuYW1lOiAnJ1xuICAgIH0sXG4gICAgY29tcG9uZW50czoge1xuICAgICAgICAvLyBkZWZhdWx0IGV4cG9ydCBtaWdodCBub3QgZXhpc3Qgd2hlbiBvcHRpbWl6ZWQgZm9yIGRhdGEgb25seVxuICAgICAgICBBcHA6IGFwcC5kZWZhdWx0LFxuICAgICAgICBEb2N1bWVudDogZG9jdW1lbnQuZGVmYXVsdFxuICAgIH0sXG4gICAgdXNlcmxhbmRcbn0pO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYWdlcy5qcy5tYXAiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fpost_id&preferredRegion=&absolutePagePath=.%2Fpages%5Cpost_id.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./pages/post_id.js":
/*!**************************!*\
  !*** ./pages/post_id.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Post)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nconst posts = [\n    {\n        \"id\": \"1\",\n        \"title\": \"پست اول\",\n        \"description\": \"توضیح کوتاه برای پست اول\",\n        \"content\": \"متن کامل پست اول\",\n        \"date\": \"2024-11-30\"\n    },\n    {\n        \"id\": \"2\",\n        \"title\": \"پست دوم\",\n        \"description\": \"توضیح کوتاه برای پست دوم\",\n        \"content\": \"متن کامل پست دوم\",\n        \"date\": \"2024-11-29\"\n    },\n    {\n        \"id\": \"3\",\n        \"title\": \"پست سوم\",\n        \"description\": \"توضیح کوتاه برای پست سوم\",\n        \"content\": \"متن کامل پست سوم\",\n        \"date\": \"2024-11-28\"\n    },\n    {\n        \"id\": \"4\",\n        \"title\": \"پست چهارم\",\n        \"description\": \"توضیح کوتاه برای پست چهارم\",\n        \"content\": \"متن کامل پست چهارم\",\n        \"date\": \"2024-11-27\"\n    },\n    {\n        \"id\": \"5\",\n        \"title\": \"پست پنجم\",\n        \"description\": \"توضیح کوتاه برای پست پنجم\",\n        \"content\": \"متن کامل پست پنجم\",\n        \"date\": \"2024-11-26\"\n    },\n    {\n        \"id\": \"6\",\n        \"title\": \"پست ششم\",\n        \"description\": \"توضیح کوتاه برای پست ششم\",\n        \"content\": \"متن کامل پست ششم\",\n        \"date\": \"2024-11-25\"\n    },\n    {\n        \"id\": \"7\",\n        \"title\": \"پست هفتم\",\n        \"description\": \"توضیح کوتاه برای پست هفتم\",\n        \"content\": \"متن کامل پست هفتم\",\n        \"date\": \"2024-11-24\"\n    },\n    {\n        \"id\": \"8\",\n        \"title\": \"پست هشتم\",\n        \"description\": \"توضیح کوتاه برای پست هشتم\",\n        \"content\": \"متن کامل پست هشتم\",\n        \"date\": \"2024-11-23\"\n    },\n    {\n        \"id\": \"9\",\n        \"title\": \"پست نهم\",\n        \"description\": \"توضیح کوتاه برای پست نهم\",\n        \"content\": \"متن کامل پست نهم\",\n        \"date\": \"2024-11-22\"\n    },\n    {\n        \"id\": \"10\",\n        \"title\": \"پست دهم\",\n        \"description\": \"توضیح کوتاه برای پست دهم\",\n        \"content\": \"متن کامل پست دهم\",\n        \"date\": \"2024-11-21\"\n    }\n];\nfunction Post() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const { id } = router.query;\n    // پیدا کردن پست بر اساس id  \n    const post = posts.find((p)=>p.id === id);\n    if (!post) return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        children: \"پست مورد نظر یافت نشد.\"\n    }, void 0, false, {\n        fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n        lineNumber: 85,\n        columnNumber: 21\n    }, this); // در صورتی که پست وجود نداشته باشد  \n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                    children: post.title\n                }, void 0, false, {\n                    fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                    lineNumber: 90,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                lineNumber: 89,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: post.title\n            }, void 0, false, {\n                fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                lineNumber: 92,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: post.description\n            }, void 0, false, {\n                fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                lineNumber: 93,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                children: [\n                    \"تاریخ: \",\n                    post.date\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                lineNumber: 94,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: post.content\n            }, void 0, false, {\n                fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                lineNumber: 95,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n                href: \"/\",\n                children: \"برگشت به صفحه اصلی\"\n            }, void 0, false, {\n                fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n                lineNumber: 96,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\21\\\\nextjs\\\\my-next-app\\\\pages\\\\post_id.js\",\n        lineNumber: 88,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9wb3N0X2lkLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBd0M7QUFDWDtBQUNBO0FBRTdCLE1BQU1HLFFBQVE7SUFDVjtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7SUFDQTtRQUNFLE1BQU07UUFDTixTQUFTO1FBQ1QsZUFBZTtRQUNmLFdBQVc7UUFDWCxRQUFRO0lBQ1Y7Q0FDRDtBQUVZLFNBQVNDO0lBQ3RCLE1BQU1DLFNBQVNMLHNEQUFTQTtJQUN4QixNQUFNLEVBQUVNLEVBQUUsRUFBRSxHQUFHRCxPQUFPRSxLQUFLO0lBRTNCLDZCQUE2QjtJQUM3QixNQUFNQyxPQUFPTCxNQUFNTSxJQUFJLENBQUMsQ0FBQ0MsSUFBTUEsRUFBRUosRUFBRSxLQUFLQTtJQUV4QyxJQUFJLENBQUNFLE1BQU0scUJBQU8sOERBQUNFO2tCQUFFOzs7OztjQUE0QixxQ0FBcUM7SUFFdEYscUJBQ0UsOERBQUNDOzswQkFDQyw4REFBQ1Ysa0RBQUlBOzBCQUNILDRFQUFDVzs4QkFBT0osS0FBS0ksS0FBSzs7Ozs7Ozs7Ozs7MEJBRXBCLDhEQUFDQzswQkFBSUwsS0FBS0ksS0FBSzs7Ozs7OzBCQUNmLDhEQUFDRjswQkFBR0YsS0FBS00sV0FBVzs7Ozs7OzBCQUNwQiw4REFBQ0o7O29CQUFFO29CQUFRRixLQUFLTyxJQUFJOzs7Ozs7OzBCQUNwQiw4REFBQ0o7MEJBQUtILEtBQUtRLE9BQU87Ozs7OzswQkFDbEIsOERBQUNkLGtEQUFJQTtnQkFBQ2UsTUFBSzswQkFBSTs7Ozs7Ozs7Ozs7O0FBR3JCIiwic291cmNlcyI6WyJEOlxcMjFcXG5leHRqc1xcbXktbmV4dC1hcHBcXHBhZ2VzXFxwb3N0X2lkLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJzsgIFxyXG5pbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnOyAgXHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7ICBcclxuXHJcbmNvbnN0IHBvc3RzID0gW1xyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiMVwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINin2YjZhFwiLFxyXG4gICAgICBcImRlc2NyaXB0aW9uXCI6IFwi2KrZiNi224zYrSDaqdmI2KrYp9mHINio2LHYp9uMINm+2LPYqiDYp9mI2YRcIixcclxuICAgICAgXCJjb250ZW50XCI6IFwi2YXYqtmGINqp2KfZhdmEINm+2LPYqiDYp9mI2YRcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0zMFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiMlwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINiv2YjZhVwiLFxyXG4gICAgICBcImRlc2NyaXB0aW9uXCI6IFwi2KrZiNi224zYrSDaqdmI2KrYp9mHINio2LHYp9uMINm+2LPYqiDYr9mI2YVcIixcclxuICAgICAgXCJjb250ZW50XCI6IFwi2YXYqtmGINqp2KfZhdmEINm+2LPYqiDYr9mI2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yOVwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiM1wiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINiz2YjZhVwiLFxyXG4gICAgICBcImRlc2NyaXB0aW9uXCI6IFwi2KrZiNi224zYrSDaqdmI2KrYp9mHINio2LHYp9uMINm+2LPYqiDYs9mI2YVcIixcclxuICAgICAgXCJjb250ZW50XCI6IFwi2YXYqtmGINqp2KfZhdmEINm+2LPYqiDYs9mI2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yOFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiNFwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINqG2YfYp9ix2YVcIixcclxuICAgICAgXCJkZXNjcmlwdGlvblwiOiBcItiq2YjYttuM2K0g2qnZiNiq2KfZhyDYqNix2KfbjCDZvtiz2Kog2obZh9in2LHZhVwiLFxyXG4gICAgICBcImNvbnRlbnRcIjogXCLZhdiq2YYg2qnYp9mF2YQg2b7Ys9iqINqG2YfYp9ix2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yN1wiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiNVwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINm+2YbYrNmFXCIsXHJcbiAgICAgIFwiZGVzY3JpcHRpb25cIjogXCLYqtmI2LbbjNitINqp2YjYqtin2Ycg2KjYsdin24wg2b7Ys9iqINm+2YbYrNmFXCIsXHJcbiAgICAgIFwiY29udGVudFwiOiBcItmF2KrZhiDaqdin2YXZhCDZvtiz2Kog2b7Zhtis2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yNlwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiNlwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINi02LTZhVwiLFxyXG4gICAgICBcImRlc2NyaXB0aW9uXCI6IFwi2KrZiNi224zYrSDaqdmI2KrYp9mHINio2LHYp9uMINm+2LPYqiDYtNi02YVcIixcclxuICAgICAgXCJjb250ZW50XCI6IFwi2YXYqtmGINqp2KfZhdmEINm+2LPYqiDYtNi02YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yNVwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiN1wiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINmH2YHYqtmFXCIsXHJcbiAgICAgIFwiZGVzY3JpcHRpb25cIjogXCLYqtmI2LbbjNitINqp2YjYqtin2Ycg2KjYsdin24wg2b7Ys9iqINmH2YHYqtmFXCIsXHJcbiAgICAgIFwiY29udGVudFwiOiBcItmF2KrZhiDaqdin2YXZhCDZvtiz2Kog2YfZgdiq2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yNFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiOFwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINmH2LTYqtmFXCIsXHJcbiAgICAgIFwiZGVzY3JpcHRpb25cIjogXCLYqtmI2LbbjNitINqp2YjYqtin2Ycg2KjYsdin24wg2b7Ys9iqINmH2LTYqtmFXCIsXHJcbiAgICAgIFwiY29udGVudFwiOiBcItmF2KrZhiDaqdin2YXZhCDZvtiz2Kog2YfYtNiq2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yM1wiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiOVwiLFxyXG4gICAgICBcInRpdGxlXCI6IFwi2b7Ys9iqINmG2YfZhVwiLFxyXG4gICAgICBcImRlc2NyaXB0aW9uXCI6IFwi2KrZiNi224zYrSDaqdmI2KrYp9mHINio2LHYp9uMINm+2LPYqiDZhtmH2YVcIixcclxuICAgICAgXCJjb250ZW50XCI6IFwi2YXYqtmGINqp2KfZhdmEINm+2LPYqiDZhtmH2YVcIixcclxuICAgICAgXCJkYXRlXCI6IFwiMjAyNC0xMS0yMlwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcImlkXCI6IFwiMTBcIixcclxuICAgICAgXCJ0aXRsZVwiOiBcItm+2LPYqiDYr9mH2YVcIixcclxuICAgICAgXCJkZXNjcmlwdGlvblwiOiBcItiq2YjYttuM2K0g2qnZiNiq2KfZhyDYqNix2KfbjCDZvtiz2Kog2K/Zh9mFXCIsXHJcbiAgICAgIFwiY29udGVudFwiOiBcItmF2KrZhiDaqdin2YXZhCDZvtiz2Kog2K/Zh9mFXCIsXHJcbiAgICAgIFwiZGF0ZVwiOiBcIjIwMjQtMTEtMjFcIlxyXG4gICAgfVxyXG4gIF1cclxuICA7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBvc3QoKSB7ICBcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTsgIFxyXG4gIGNvbnN0IHsgaWQgfSA9IHJvdXRlci5xdWVyeTsgIFxyXG5cclxuICAvLyDZvtuM2K/YpyDaqdix2K/ZhiDZvtiz2Kog2KjYsSDYp9iz2KfYsyBpZCAgXHJcbiAgY29uc3QgcG9zdCA9IHBvc3RzLmZpbmQoKHApID0+IHAuaWQgPT09IGlkKTsgIFxyXG5cclxuICBpZiAoIXBvc3QpIHJldHVybiA8cD7Zvtiz2Kog2YXZiNix2K8g2YbYuNixINuM2KfZgdiqINmG2LTYry48L3A+OyAvLyDYr9ixINi12YjYsdiq24wg2qnZhyDZvtiz2Kog2YjYrNmI2K8g2YbYr9in2LTYqtmHINio2KfYtNivICBcclxuXHJcbiAgcmV0dXJuICggIFxyXG4gICAgPGRpdj4gIFxyXG4gICAgICA8SGVhZD4gIFxyXG4gICAgICAgIDx0aXRsZT57cG9zdC50aXRsZX08L3RpdGxlPiAgXHJcbiAgICAgIDwvSGVhZD4gIFxyXG4gICAgICA8aDE+e3Bvc3QudGl0bGV9PC9oMT4gIFxyXG4gICAgICA8cD57cG9zdC5kZXNjcmlwdGlvbn08L3A+ICBcclxuICAgICAgPHA+2KrYp9ix24zYrjoge3Bvc3QuZGF0ZX08L3A+ICBcclxuICAgICAgPGRpdj57cG9zdC5jb250ZW50fTwvZGl2PiAgXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvXCI+2KjYsdqv2LTYqiDYqNmHINi12YHYrdmHINin2LXZhNuMPC9MaW5rPiAgXHJcbiAgICA8L2Rpdj4gIFxyXG4gICk7ICBcclxufSJdLCJuYW1lcyI6WyJ1c2VSb3V0ZXIiLCJIZWFkIiwiTGluayIsInBvc3RzIiwiUG9zdCIsInJvdXRlciIsImlkIiwicXVlcnkiLCJwb3N0IiwiZmluZCIsInAiLCJkaXYiLCJ0aXRsZSIsImgxIiwiZGVzY3JpcHRpb24iLCJkYXRlIiwiY29udGVudCIsImhyZWYiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/post_id.js\n");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fpost_id&preferredRegion=&absolutePagePath=.%2Fpages%5Cpost_id.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();