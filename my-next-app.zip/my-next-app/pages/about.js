import Head from 'next/head';  
import Link from 'next/link';  

export default function About() {  
  return (  
    <div>  
      <Head>  
        <title>درباره ما - فاطمه راد</title>  
      </Head>  
      <h1>درباره ما</h1>  
      <p>این صفحه حاوی اطلاعات درباره وب‌سایت است.</p>  
      <nav>  
        <ul>  
          <li><Link href="/">صفحه اصلی</Link></li>  
          <li><Link href="/about">درباره ما</Link></li>  
        </ul>  
      </nav>  
    </div>  
  );  
}