import Head from 'next/head';  
import Link from 'next/link';  

const posts = [
    {
      "id": "1",
      "title": "پست اول",
      "description": "توضیح کوتاه برای پست اول",
      "content": "متن کامل پست اول",
      "date": "2024-11-30"
    },
    {
      "id": "2",
      "title": "پست دوم",
      "description": "توضیح کوتاه برای پست دوم",
      "content": "متن کامل پست دوم",
      "date": "2024-11-29"
    },
    {
      "id": "3",
      "title": "پست سوم",
      "description": "توضیح کوتاه برای پست سوم",
      "content": "متن کامل پست سوم",
      "date": "2024-11-28"
    },
    {
      "id": "4",
      "title": "پست چهارم",
      "description": "توضیح کوتاه برای پست چهارم",
      "content": "متن کامل پست چهارم",
      "date": "2024-11-27"
    },
    {
      "id": "5",
      "title": "پست پنجم",
      "description": "توضیح کوتاه برای پست پنجم",
      "content": "متن کامل پست پنجم",
      "date": "2024-11-26"
    },
    {
      "id": "6",
      "title": "پست ششم",
      "description": "توضیح کوتاه برای پست ششم",
      "content": "متن کامل پست ششم",
      "date": "2024-11-25"
    },
    {
      "id": "7",
      "title": "پست هفتم",
      "description": "توضیح کوتاه برای پست هفتم",
      "content": "متن کامل پست هفتم",
      "date": "2024-11-24"
    },
    {
      "id": "8",
      "title": "پست هشتم",
      "description": "توضیح کوتاه برای پست هشتم",
      "content": "متن کامل پست هشتم",
      "date": "2024-11-23"
    },
    {
      "id": "9",
      "title": "پست نهم",
      "description": "توضیح کوتاه برای پست نهم",
      "content": "متن کامل پست نهم",
      "date": "2024-11-22"
    },
    {
      "id": "10",
      "title": "پست دهم",
      "description": "توضیح کوتاه برای پست دهم",
      "content": "متن کامل پست دهم",
      "date": "2024-11-21"
    }
  ]
  ;  


  export default function Home() {  
    return (  
      <div>  
        <Head>  
          <title>صفحه اصلی</title>  
        </Head>  
        <h1>به وب‌سایت من خوش آمدید!</h1>  
        <nav>  
          <ul>  
            <li>  
              <Link href="/about">درباره ما</Link>  
            </li>  
            {posts.map(post => (  
              <li key={post.id}>  
                <Link href={`/post_id?id=${post.id}`}>  
                  {post.title}  
                </Link>  
              </li>  
            ))}  
          </ul>  
        </nav>  
      </div>  
    );  
  }  